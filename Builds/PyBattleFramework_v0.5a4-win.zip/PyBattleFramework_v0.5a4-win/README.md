PyBattleFramework
=================

Shirra's Ren'Py Battle Framework

Uses Ren'Py v6.18.3.761
http://www.renpy.org/latest.html
With Editra manually loaded in for editing and easier resolution of traceback information.
( From the same page, near the bottom. )

...  Current programming status - Lots of Raptors.
http://imgs.xkcd.com/comics/goto.png

